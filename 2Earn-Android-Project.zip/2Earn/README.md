# 2Earn — Android Earning App (Starter Project)

Ye ek complete Android Studio project hai jisme:
- Coin wallet system (SharedPreferences-based)
- AdMob **Rewarded Video Ads** se coins kamana
- Task list (daily check-in, ads, survey/offerwall placeholders)
- UPI withdrawal request screen
- Transaction history screen

## ⚠️ Pehle ye 3 cheezein zaroor samjho

1. **Maine APK build nahi kiya hai.** Ye source code hai — tumhe Android Studio
   mein khol ke build karna hoga (mere paas yahan Android SDK/build environment
   nahi hai).
2. **Ads abhi TEST mode mein hain.** `AndroidManifest.xml` aur `MainActivity.kt`
   mein Google ke **official test IDs** lagaye hain — jab tak tum apne real
   AdMob App ID/Ad Unit ID nahi daalte, tumhe ek rupaya bhi revenue nahi
   milega.
3. **Withdrawal abhi sirf "request record" karta hai, real paisa nahi
   bhejta.** Real UPI payout ke liye tumhe ek backend server chahiye hoga
   (neeche detail hai) — ye client-side app se directly safely nahi ho sakta.

## Step-by-Step Setup

### 1. AdMob Account Banao
- https://admob.google.com pe jaake account banao
- Naya App add karo → "2Earn"
- Ek **Rewarded Ad Unit** banao, uska Ad Unit ID copy karo
- `AndroidManifest.xml` mein `APPLICATION_ID` ko apne real App ID se replace karo
- `MainActivity.kt` mein `rewardedAdUnitId` variable ko apne real Ad Unit ID se replace karo

### 2. App Build Karo
- Android Studio (latest version) install karo
- Is `2Earn` folder ko "Open" karo (File → Open)
- Gradle sync hone do (internet chahiye hoga first time)
- `Run` button dabao (emulator ya real phone pe)

### 3. Real Withdrawal (UPI/Paytm) Ke Liye Backend Banao
App khud directly kisi ke UPI account mein paisa nahi bhej sakta — security
risk hota hai. Tumhe ek simple backend chahiye:

- **Razorpay Payouts** ya **Cashfree Payouts** account banao (business KYC
  required hoga)
- Ek backend banao (Node.js/Firebase Cloud Functions) jo:
  1. App se withdrawal request receive kare
  2. User ka balance database mein verify kare
  3. Razorpay/Cashfree Payout API call kare (API keys sirf backend mein, kabhi
     app mein nahi)
  4. Status wapas app ko bheje
- `WithdrawActivity.kt` mein `submitWithdrawalToBackend()` function hai — wahin
  pe apna backend API call jodo (comments mein example diya hai)

### 4. Production Mein Jaane Se Pehle: User Database
Abhi coin balance sirf phone ke local storage mein store hai
(`WalletManager.kt`). Production app ke liye ye **move karna zaroori hai**
kisi real backend/database (Firebase Firestore ya apna server) mein —
warna users app data clear karke ya root kiye phone se balance fake kar
sakte hain, aur tumhe real paisa nuksaan hoga.

## ⚠️ Google Play Store Policy Warning

Google Play "cash/rewards for engagement" apps ko bahut strictly review
karta hai. Rejection/ban se bachne ke liye:
- Clearly disclose karo ki rewards kaise kamaye jaate hain
- Misleading claims mat karo ("Earn ₹5000/day guaranteed" jaisi cheezein
  avoid karo)
- AdMob policy follow karo — incentivizing users sirf ads click karne ke
  liye (na ki dekhne ke liye) policy violation hai
- Withdrawal process transparent aur reliable rakho

Submit karne se pehle [Play Console Policy Center](https://support.google.com/googleplay/android-developer/answer/9899234)
zaroor padh lena.

## Project Structure
```
app/src/main/java/com/twoearn/app/
├── data/
│   ├── WalletManager.kt      → coin balance, transactions
│   └── EarnTask.kt           → task model + sample task list
└── ui/
    ├── MainActivity.kt       → home screen + AdMob rewarded ad logic
    ├── TaskListActivity.kt   → task list screen
    ├── TaskAdapter.kt
    ├── WithdrawActivity.kt   → UPI withdrawal request
    ├── HistoryActivity.kt    → transaction history
```

## Customization Points
| Cheez | File | Kya badlo |
|---|---|---|
| Coin-to-rupee rate | `WalletManager.kt` | `COINS_PER_RUPEE` |
| Min withdrawal | `WalletManager.kt` | `MIN_WITHDRAW_RUPEES` |
| Ad reward amount | `WalletManager.kt` | `COINS_PER_AD_WATCH` |
| App color theme | `res/values/colors.xml` | primary/accent colors |
| Tasks list | `EarnTask.kt` | `TaskRepository.getSampleTasks()` |
