package com.twoearn.app.data

data class EarnTask(
    val id: String,
    val title: String,
    val description: String,
    val coinReward: Long,
    val type: TaskType
)

enum class TaskType {
    WATCH_AD,
    DAILY_CHECKIN,
    SURVEY,
    APP_INSTALL
}

object TaskRepository {
    fun getSampleTasks(): List<EarnTask> = listOf(
        EarnTask(
            id = "daily_checkin",
            title = "Daily Check-in",
            description = "Open the app and check in today",
            coinReward = 10,
            type = TaskType.DAILY_CHECKIN
        ),
        EarnTask(
            id = "watch_ad_1",
            title = "Watch a Video Ad",
            description = "Watch a short rewarded video ad",
            coinReward = WalletManager.COINS_PER_AD_WATCH.toLong(),
            type = TaskType.WATCH_AD
        ),
        EarnTask(
            id = "survey_1",
            title = "Complete a Quick Survey",
            description = "Answer a short survey (plug in a real survey-wall SDK like AdGem / Bitlabs here)",
            coinReward = 50,
            type = TaskType.SURVEY
        ),
        EarnTask(
            id = "install_1",
            title = "Try a Partner App",
            description = "Install and open a partner app (plug in an offerwall SDK like Tapjoy / Fyber here)",
            coinReward = 100,
            type = TaskType.APP_INSTALL
        )
    )
}
