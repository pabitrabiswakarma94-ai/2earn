package com.twoearn.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local wallet/coin manager.
 *
 * NOTE: This stores coins on-device only (SharedPreferences). That is fine
 * for a demo/MVP, but for a real production app you MUST move coin balance
 * and transaction history to a server (Firebase Firestore / your own backend)
 * — otherwise users can fake their balance by rooting their phone or editing
 * app data, and you will lose real money on withdrawals.
 */
object WalletManager {

    private const val PREFS_NAME = "two_earn_wallet"
    private const val KEY_COINS = "coin_balance"
    private const val KEY_TRANSACTIONS = "transactions"
    private const val KEY_LAST_AD_TIME = "last_ad_time"
    private const val KEY_COMPLETED_TASKS = "completed_task_ids"

    // ---- Conversion rate: tune this to your business model ----
    // 1000 coins = ₹1  (i.e. 1 coin = ₹0.001) — adjust as needed
    const val COINS_PER_RUPEE = 1000
    const val MIN_WITHDRAW_RUPEES = 50
    const val COINS_PER_AD_WATCH = 20
    const val AD_COOLDOWN_MS = 30_000L // 30 sec between ad rewards (anti-spam)

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getBalance(context: Context): Long =
        prefs(context).getLong(KEY_COINS, 0L)

    fun getBalanceInRupees(context: Context): Double =
        getBalance(context).toDouble() / COINS_PER_RUPEE

    fun canWatchAd(context: Context): Boolean {
        val last = prefs(context).getLong(KEY_LAST_AD_TIME, 0L)
        return System.currentTimeMillis() - last >= AD_COOLDOWN_MS
    }

    fun addCoins(context: Context, amount: Long, reason: String) {
        val p = prefs(context)
        val newBalance = getBalance(context) + amount
        p.edit()
            .putLong(KEY_COINS, newBalance)
            .putLong(KEY_LAST_AD_TIME, System.currentTimeMillis())
            .apply()
        addTransaction(context, reason, amount)
    }

    fun deductCoins(context: Context, amount: Long): Boolean {
        val current = getBalance(context)
        if (current < amount) return false
        prefs(context).edit().putLong(KEY_COINS, current - amount).apply()
        addTransaction(context, "Withdrawal", -amount)
        return true
    }

    fun isTaskCompleted(context: Context, taskId: String): Boolean {
        val set = prefs(context).getStringSet(KEY_COMPLETED_TASKS, emptySet()) ?: emptySet()
        return set.contains(taskId)
    }

    fun markTaskCompleted(context: Context, taskId: String) {
        val p = prefs(context)
        val set = (p.getStringSet(KEY_COMPLETED_TASKS, emptySet()) ?: emptySet()).toMutableSet()
        set.add(taskId)
        p.edit().putStringSet(KEY_COMPLETED_TASKS, set).apply()
    }

    private fun addTransaction(context: Context, reason: String, amount: Long) {
        val p = prefs(context)
        val arr = JSONArray(p.getString(KEY_TRANSACTIONS, "[]"))
        val obj = JSONObject()
        obj.put("reason", reason)
        obj.put("amount", amount)
        obj.put("timestamp", System.currentTimeMillis())
        arr.put(obj)
        p.edit().putString(KEY_TRANSACTIONS, arr.toString()).apply()
    }

    fun getTransactions(context: Context): List<Transaction> {
        val p = prefs(context)
        val arr = JSONArray(p.getString(KEY_TRANSACTIONS, "[]"))
        val list = mutableListOf<Transaction>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Transaction(
                    reason = o.getString("reason"),
                    amount = o.getLong("amount"),
                    timestamp = o.getLong("timestamp")
                )
            )
        }
        return list.reversed()
    }
}

data class Transaction(
    val reason: String,
    val amount: Long,
    val timestamp: Long
)
