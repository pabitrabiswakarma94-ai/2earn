package com.twoearn.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.twoearn.app.data.Transaction
import com.twoearn.app.data.WalletManager
import com.twoearn.app.databinding.ActivityHistoryBinding
import com.twoearn.app.databinding.ItemTransactionBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val transactions = WalletManager.getTransactions(this)
        binding.historyRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.historyRecyclerView.adapter = TransactionAdapter(transactions)
    }
}

class TransactionAdapter(private val items: List<Transaction>) :
    RecyclerView.Adapter<TransactionAdapter.VH>() {

    inner class VH(val binding: ItemTransactionBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val txn = items[position]
        holder.binding.txnReason.text = txn.reason
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        holder.binding.txnDate.text = sdf.format(Date(txn.timestamp))
        val sign = if (txn.amount >= 0) "+" else ""
        holder.binding.txnAmount.text = "$sign${txn.amount} coins"
        holder.binding.txnAmount.setTextColor(
            if (txn.amount >= 0)
                android.graphics.Color.parseColor("#2E7D32")
            else
                android.graphics.Color.parseColor("#C62828")
        )
    }

    override fun getItemCount(): Int = items.size
}
