package com.twoearn.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.twoearn.app.data.WalletManager
import com.twoearn.app.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var rewardedAd: RewardedAd? = null

    // TODO: Replace with your REAL AdMob Rewarded Ad Unit ID before publishing.
    // This is Google's official TEST ad unit ID — safe to use during development,
    // but you will earn ₹0 real revenue until you swap this for your live ID.
    private val rewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MobileAds.initialize(this) {}
        loadRewardedAd()

        binding.watchAdButton.setOnClickListener { onWatchAdClicked() }
        binding.tasksButton.setOnClickListener {
            startActivity(Intent(this, TaskListActivity::class.java))
        }
        binding.withdrawButton.setOnClickListener {
            startActivity(Intent(this, WithdrawActivity::class.java))
        }
        binding.historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Daily check-in reward (once per day, simple example)
        if (!WalletManager.isTaskCompleted(this, "daily_checkin_${todayKey()}")) {
            WalletManager.addCoins(this, 10, "Daily Check-in")
            WalletManager.markTaskCompleted(this, "daily_checkin_${todayKey()}")
            Toast.makeText(this, "+10 coins for daily check-in!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshBalance()
    }

    private fun todayKey(): String {
        val sdf = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }

    private fun refreshBalance() {
        val coins = WalletManager.getBalance(this)
        val rupees = WalletManager.getBalanceInRupees(this)
        binding.coinBalanceText.text = "$coins Coins"
        binding.rupeeEquivalentText.text = "≈ ₹${DecimalFormat("#,##0.00").format(rupees)}"
    }

    private fun loadRewardedAd() {
        val request = AdRequest.Builder().build()
        RewardedAd.load(this, rewardedAdUnitId, request, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
            }
        })
    }

    private fun onWatchAdClicked() {
        if (!WalletManager.canWatchAd(this)) {
            Toast.makeText(this, "Please wait a bit before watching another ad", Toast.LENGTH_SHORT).show()
            return
        }

        val ad = rewardedAd
        if (ad == null) {
            Toast.makeText(this, "Ad not ready yet, try again in a moment", Toast.LENGTH_SHORT).show()
            loadRewardedAd()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewardedAd() // preload next ad
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                rewardedAd = null
                loadRewardedAd()
            }
        }

        ad.show(this) { rewardItem ->
            // User watched the full ad — reward them with coins
            WalletManager.addCoins(this, WalletManager.COINS_PER_AD_WATCH.toLong(), "Watched Ad")
            refreshBalance()
            Toast.makeText(
                this,
                "+${WalletManager.COINS_PER_AD_WATCH} coins added!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
