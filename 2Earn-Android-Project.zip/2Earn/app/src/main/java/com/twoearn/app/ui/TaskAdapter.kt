package com.twoearn.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.twoearn.app.data.EarnTask
import com.twoearn.app.databinding.ItemTaskBinding

class TaskAdapter(
    private val tasks: List<EarnTask>,
    private val isCompleted: (EarnTask) -> Boolean,
    private val onTaskClick: (EarnTask) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.binding.taskTitle.text = task.title
        holder.binding.taskDescription.text = task.description
        holder.binding.taskReward.text = "+${task.coinReward} coins"

        val done = isCompleted(task)
        holder.binding.taskActionButton.text = if (done) "Done" else "Go"
        holder.binding.taskActionButton.isEnabled = !done

        holder.binding.taskActionButton.setOnClickListener {
            onTaskClick(task)
        }
    }

    override fun getItemCount(): Int = tasks.size
}
