package com.twoearn.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.twoearn.app.data.TaskRepository
import com.twoearn.app.data.TaskType
import com.twoearn.app.data.WalletManager
import com.twoearn.app.databinding.ActivityTaskListBinding

class TaskListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTaskListBinding
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val tasks = TaskRepository.getSampleTasks()
        adapter = TaskAdapter(
            tasks = tasks,
            isCompleted = { task -> WalletManager.isTaskCompleted(this, task.id) },
            onTaskClick = { task -> handleTaskClick(task) }
        )

        binding.taskRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.taskRecyclerView.adapter = adapter
    }

    private fun handleTaskClick(task: com.twoearn.app.data.EarnTask) {
        when (task.type) {
            TaskType.WATCH_AD -> {
                // Reuse the same rewarded-ad flow as the home screen.
                // For simplicity here we just credit coins directly;
                // in production, wire this to the same RewardedAd logic as MainActivity.
                Toast.makeText(this, "Go to Home screen and tap 'Watch Ad to Earn Coins'", Toast.LENGTH_LONG).show()
                return
            }
            TaskType.DAILY_CHECKIN -> {
                completeTask(task)
            }
            TaskType.SURVEY -> {
                // TODO: integrate a real survey-wall SDK (e.g. Bitlabs, AdGem, Pollfish)
                Toast.makeText(this, "Survey SDK not yet integrated — plug in a provider here", Toast.LENGTH_LONG).show()
            }
            TaskType.APP_INSTALL -> {
                // TODO: integrate a real offerwall SDK (e.g. Tapjoy, Fyber)
                Toast.makeText(this, "Offerwall SDK not yet integrated — plug in a provider here", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun completeTask(task: com.twoearn.app.data.EarnTask) {
        if (WalletManager.isTaskCompleted(this, task.id)) return
        WalletManager.addCoins(this, task.coinReward, task.title)
        WalletManager.markTaskCompleted(this, task.id)
        Toast.makeText(this, "+${task.coinReward} coins!", Toast.LENGTH_SHORT).show()
        adapter.notifyDataSetChanged()
    }
}
