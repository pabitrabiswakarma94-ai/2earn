package com.twoearn.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.twoearn.app.data.WalletManager
import com.twoearn.app.databinding.ActivityWithdrawBinding
import java.text.DecimalFormat

/**
 * IMPORTANT — REAL MONEY NOTE:
 *
 * This screen only RECORDS a withdrawal request locally and deducts the coins.
 * It does NOT actually send money to anyone's UPI ID — that requires a secure
 * backend server because:
 *   1. You cannot put real payout API keys (Razorpay/Cashfree/PayU Payouts)
 *      inside an Android app — anyone can decompile the APK and steal your keys.
 *   2. Payout APIs require server-side calls with your business KYC credentials.
 *
 * Real-world flow you need to build separately:
 *   App -> sends withdrawal request -> Your backend (Node/Firebase Functions)
 *        -> verifies balance in your database -> calls Razorpay Payouts API
 *        -> updates request status -> notifies the app
 *
 * For now this class simulates "request submitted, pending review" — wire the
 * actual API call in submitWithdrawalToBackend() once your backend is ready.
 */
class WithdrawActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWithdrawBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWithdrawBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        refreshBalance()

        binding.submitWithdrawButton.setOnClickListener { onSubmitClicked() }
    }

    private fun refreshBalance() {
        val rupees = WalletManager.getBalanceInRupees(this)
        binding.availableBalanceText.text = "Available: ₹${DecimalFormat("#,##0.00").format(rupees)}"
    }

    private fun onSubmitClicked() {
        val upiId = binding.upiIdInput.text?.toString()?.trim() ?: ""
        val amountStr = binding.amountInput.text?.toString()?.trim() ?: ""

        if (upiId.isEmpty() || !upiId.contains("@")) {
            Toast.makeText(this, "Enter a valid UPI ID (e.g. name@upi)", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        if (amount < WalletManager.MIN_WITHDRAW_RUPEES) {
            Toast.makeText(
                this,
                "Minimum withdrawal is ₹${WalletManager.MIN_WITHDRAW_RUPEES}",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val availableRupees = WalletManager.getBalanceInRupees(this)
        if (amount > availableRupees) {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show()
            return
        }

        val coinsToDeduct = (amount * WalletManager.COINS_PER_RUPEE).toLong()
        val success = WalletManager.deductCoins(this, coinsToDeduct)

        if (success) {
            submitWithdrawalToBackend(upiId, amount)
            Toast.makeText(
                this,
                "Withdrawal request submitted! It will be processed within 24-48 hours.",
                Toast.LENGTH_LONG
            ).show()
            refreshBalance()
            binding.upiIdInput.text?.clear()
            binding.amountInput.text?.clear()
        } else {
            Toast.makeText(this, "Something went wrong. Try again.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun submitWithdrawalToBackend(upiId: String, amountRupees: Double) {
        // TODO: Replace with a real network call to your backend, e.g.:
        //
        // val json = JSONObject().apply {
        //     put("upiId", upiId)
        //     put("amount", amountRupees)
        //     put("userId", currentUserId)
        // }
        // OkHttpClient call to https://your-backend.com/api/withdraw
        //
        // Your backend then calls Razorpay Payouts / Cashfree Payouts using
        // YOUR business API keys (never store these in the app).
    }
}
